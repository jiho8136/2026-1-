# 📁 src/assets

이 폴더에는 앱에서 사용할 이미지, 폰트, 기타 정적 리소스가 들어갑니다.

## 필요한 에셋 (STEP 9에서 추가 예정)

### 앱 아이콘 / 스플래시
- `icon.png` — 앱 아이콘 (1024×1024)
- `adaptive-icon.png` — 안드로이드 적응형 아이콘 (1024×1024)
- `splash.png` — 스플래시 화면
- `favicon.png` — 웹 favicon
- `notification-icon.png` — 푸시 알림 아이콘 (96×96, 단색)

### 하냥이 캐릭터 (hanyangi/ 폴더)
파일명 규칙: `{violenceLevel}_{mood}.png`

- `1_happy.png`, `1_neutral.png`, `1_worried.png`, ...
- `2_happy.png`, `2_angry.png`, ...
- `3_furious.png`, `3_angry.png`, ...

총 조합: 3 violenceLevel × 7 mood = 최대 21장

### 폰트 (fonts/ 폴더)
- `Pretendard-Thin.otf`
- `Pretendard-Light.otf`
- `Pretendard-Regular.otf`
- `Pretendard-Medium.otf`
- `Pretendard-SemiBold.otf`
- `Pretendard-Bold.otf`
- `Pretendard-ExtraBold.otf`

Pretendard는 오픈소스이며 https://github.com/orioncactus/pretendard 에서 다운로드 가능.
